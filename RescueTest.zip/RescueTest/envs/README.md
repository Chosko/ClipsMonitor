Inserire in questa cartella i file relativi al modulo ENV.

Vengono letti solo file con estensione .CLP e .clp